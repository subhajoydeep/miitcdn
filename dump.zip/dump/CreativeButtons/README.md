
Creative Button Styles
=========
Some creative and modern button styles and effects for your inspiration. 

[article on Codrops](http://tympanus.net/codrops/?p=15430)

[demo](http://tympanus.net/Development/CreativeButtons/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)