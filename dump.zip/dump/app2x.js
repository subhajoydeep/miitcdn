/************** Login Functions *******************/
(function() {
    var loginApp=angular.module('loginApp',[]);
    loginApp.controller('ctrlLogin',['$scope', '$http', '$log', function($scope, $http, $log){
//            alert('running');
        alert();
    }]);
})();
