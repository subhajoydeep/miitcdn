document.security_sha1 = {
    'https://www.myfuturemirror.com/pujas/group-rudrabhishek-puja/105': '9703bf757ffa1715b5f0343af33ee2664cd6c692',
    'https://www.myfuturemirror.com/index':'36ec55cc494f00339ddb16534acc88d5df6d65f6',
    'https://www.myfuturemirror.com/index':'36ec55cc494f00339ddb16534acc88d5df6d65f6',
    'https://www.myfuturemirror.com/':'08563738e32af7382facc1055a073f0d5c7f28bf'
    
};
